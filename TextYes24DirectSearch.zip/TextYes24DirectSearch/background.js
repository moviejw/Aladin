chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "searchYes24",
    title: "Yes24에서 검색",
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    id: "openAladinLinks",
    title: "정보수정 다 열기",
    contexts: ["all"]
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "searchYes24" && info.selectionText) {
    chrome.tabs.create({ url: "https://uscm.yes24.com/Product/ProductList" }, (tab) => {
      const listener = (tabId, changeInfo) => {
        if (tabId === tab.id && changeInfo.status === "complete") {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (text) => {
              const input = document.querySelector('input.flex-grow-1.form-control');
              if (input) {
                input.value = text;
                input.dispatchEvent(new Event('input', { bubbles: true }));
              }
            },
            args: [info.selectionText]
          });
          chrome.tabs.onUpdated.removeListener(listener);
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
  }
  if (info.menuItemId === "openAladinLinks") {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length === 0) return;
    const tabId = tabs[0].id;

    // 현재 페이지에서 링크 수집 후 새 탭 생성
    chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        return Array.from(document.querySelectorAll('a[href^="/scm/wrecord.aspx?action=2"]'))
          .filter(a => a.querySelector('img'))
          .map(a => a.href.startsWith('http') ? a.href : 'https://www.aladin.co.kr' + a.getAttribute('href'));
      }
    }, (results) => {
      if (!results || !results[0]?.result) return;
      const links = results[0].result;
      links.forEach(url => {
        chrome.tabs.create({ url }, (newTab) => {
  const listener = (tabId, changeInfo) => {
    if (tabId === newTab.id && changeInfo.status === "complete") {
      chrome.scripting.executeScript({
        target: { tabId: newTab.id },
        func: () => {
          const interval = setInterval(() => {
            const feeEl = document.querySelector('#spanPriceSalesFee');
            const strongElements = Array.from(document.querySelectorAll('strong'));
            const minStrong = strongElements.find(el => el.textContent.includes('최저가'));
            if (feeEl && minStrong) {
              clearInterval(interval);
              const fee = parseInt(feeEl.textContent.trim()) * 10;
              const match = minStrong.textContent.match(/최저가\s*([\d,]+)원/);
              const minPrice = match ? parseInt(match[1].replace(/,/g, '')) : null;
              if (fee === minPrice) window.close();
            }
          }, 200); // 200ms마다 체크
        }
      });
      chrome.tabs.onUpdated.removeListener(listener);
    }
  };
  chrome.tabs.onUpdated.addListener(listener);
});

      });
    });
  });
}

});

