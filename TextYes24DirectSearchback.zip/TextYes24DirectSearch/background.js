chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "searchYes24",
    title: "Yes24에서 검색",
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    id: "openAladinLinks",
    title: "정보수정 다 열기",
    contexts: ["all"]
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "searchYes24" && info.selectionText) {
    chrome.tabs.create({ url: "https://uscm.yes24.com/Product/ProductList" }, (tab) => {
      const listener = (tabId, changeInfo) => {
        if (tabId === tab.id && changeInfo.status === "complete") {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (text) => {
              const input = document.querySelector('input.flex-grow-1.form-control');
              if (input) {
                input.value = text;
                input.dispatchEvent(new Event('input', { bubbles: true }));
              }
            },
            args: [info.selectionText]
          });
          chrome.tabs.onUpdated.removeListener(listener);
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
  }
  if (info.menuItemId === "openAladinLinks") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0) {
        const tabId = tabs[0].id;
        chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
            const links = Array.from(document.querySelectorAll('a[href^="/scm/wrecord.aspx?action=2"]'));
            const opened = new Set(); // 중복 방지
            links.forEach(a => {
            // <img>가 포함되어 있고 아직 열지 않은 href이면
            if (a.querySelector('img') && !opened.has(a.href)) {
                const url = a.href.startsWith('http') ? a.href : 'https://www.aladin.co.kr' + a.getAttribute('href');
                window.open(url, '_blank');
                opened.add(a.href);
            }
            });
        }
        });
      }
    });
  }
});

